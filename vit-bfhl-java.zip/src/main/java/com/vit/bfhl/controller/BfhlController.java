package com.vit.bfhl.controller;

import com.vit.bfhl.model.DataRequest;
import com.vit.bfhl.model.DataResponse;
import com.vit.bfhl.util.StringUtils;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin // allow CORS for quick testing from anywhere
public class BfhlController {

    // TODO: CHANGE THESE 4 VALUES TO YOUR DETAILS
    private static final String FULL_NAME_LOWER = "john_doe"; // full name in lowercase with underscore
    private static final String DOB_DDMMYYYY = "17091999";     // ddmmyyyy
    private static final String EMAIL = "john@xyz.com";
    private static final String ROLL = "ABCD123";

    @PostMapping("/bfhl")
    public DataResponse processData(@Valid @RequestBody DataRequest request) {
        List<String> oddNumbers = new ArrayList<>();
        List<String> evenNumbers = new ArrayList<>();
        List<String> alphabets = new ArrayList<>();
        List<String> specialChars = new ArrayList<>();
        StringBuilder alphaChars = new StringBuilder();

        long totalSum = 0;

        for (String item : request.getData()) {
            if (item == null) continue;
            if (item.matches("\d+")) { // digits only
                long num = Long.parseLong(item);
                totalSum += num;
                if (Math.abs(num) % 2 == 0) evenNumbers.add(item);
                else oddNumbers.add(item);
            } else if (item.matches("[a-zA-Z]+")) { // alphabets only
                alphabets.add(item.toUpperCase());
                alphaChars.append(item);
            } else {
                specialChars.add(item);
            }
        }

        String concat = StringUtils.alternateCapsReverse(alphaChars.toString());

        DataResponse res = new DataResponse();
        res.setIs_success(true);
        res.setUser_id(FULL_NAME_LOWER + "_" + DOB_DDMMYYYY);
        res.setEmail(EMAIL);
        res.setRoll_number(ROLL);
        res.setOdd_numbers(oddNumbers);
        res.setEven_numbers(evenNumbers);
        res.setAlphabets(alphabets);
        res.setSpecial_characters(specialChars);
        res.setSum(String.valueOf(totalSum));
        res.setConcat_string(concat);
        return res;
    }
}
