package com.vit.bfhl.model;

public class ErrorResponse {
    private boolean is_success = false;
    private String message;

    public ErrorResponse(String message) {
        this.message = message;
    }

    public boolean isIs_success() { return is_success; }
    public String getMessage() { return message; }
}
