package com.vit.bfhl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BfhlApplication {
    public static void main(String[] args) {
        SpringApplication.run(BfhlApplication.class, args);
    }
}
