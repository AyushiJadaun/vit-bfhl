package com.vit.bfhl.util;

public class StringUtils {
    public static String alternateCapsReverse(String input) {
        StringBuilder sb = new StringBuilder();
        String reversed = new StringBuilder(input).reverse().toString();
        for (int i = 0; i < reversed.length(); i++) {
            char ch = reversed.charAt(i);
            if (i % 2 == 0) sb.append(Character.toUpperCase(ch));
            else sb.append(Character.toLowerCase(ch));
        }
        return sb.toString();
    }
}
